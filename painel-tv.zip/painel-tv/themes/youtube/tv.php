<html lang="en">
    <head>
        <meta charset=utf-8/>
    </head>
    <body>
        <div id='player'>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/nV1uB3hsvdk" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </video>
        </div>
    </body>
</html>